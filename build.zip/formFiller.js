const {delay} = require("./utils")

async function uploadResume(page, filePath) {
    try {
        // console.log('Starting resume upload process...');

        // Wait for the file input element to be present
        const fileInputSelector = 'input[type="file"][accept*="pdf"]';
        await page.waitForSelector(fileInputSelector, { timeout: 5000 });

        // Setup file upload
        const input = await page.$(fileInputSelector);
        if (!input) {
            throw new Error('File input element not found');
        }

        // Upload the resume file using the full file path
        await input.uploadFile(filePath);
        // console.log('Resume file selected');

        // Extract just the filename from the path for verification
        const filename = filePath.split('\\').pop(); // This works for Windows paths
        // Alternative that works for both Windows and Unix paths:
        // const filename = filePath.replace(/^.*[\\\/]/, '');

        // Wait for and verify upload completion
        await page.waitForFunction(
            (expectedFilename) => {
                const fileNameElement = document.querySelector('.jobs-document-upload-redesign-card__file-name');
                if (fileNameElement) {
                    const displayedFilename = fileNameElement.textContent.trim();
                    return displayedFilename === expectedFilename;
                }
                return false;
            },
            { timeout: 10000 },
            filename
        );

        // Double check the upload date is present
        const uploadDateExists = await page.evaluate(() => {
            const dateElement = document.querySelector('.jobs-document-upload-redesign-card__header .t-12.t-black--light');
            return dateElement && dateElement.textContent.includes('Uploaded on');
        });

        if (!uploadDateExists) {
            throw new Error('Upload date verification failed');
        }

        // console.log('Resume upload completed and verified successfully');
    } catch (error) {
        // console.log(`Error in uploadResume: ${error.message}`);
        throw error;
    }
}

async function fillText(page, id, value) {
    try {
        // console.log(`Filling text field ${id} with value: ${value}`);
        
        // Wait for the input element
        await page.waitForSelector(`#${id}`, { timeout: 5000 });
        
        if (id.toLowerCase().includes('typeahead')) {
            // Handle typeahead input
            await page.evaluate(async ({id, value}) => {
                // Clear and set the value
                const input = document.querySelector(`#${id}`);
                input.value = '';
                input.value = value;
                
                // Trigger input event for autocomplete
                const inputEvent = new Event('input', { bubbles: true });
                input.dispatchEvent(inputEvent);
            }, {id, value});

            // Wait for autocomplete options and click first option
            try {
                // Wait for either selector to appear
                await Promise.race([
                    page.waitForSelector('.search-typeahead-v2__hit', { timeout: 2000 }),
                    page.waitForSelector('[role="option"]', { timeout: 2000 })
                ]);

                // Click the first available option
                await page.evaluate(() => {
                    const firstOption = document.querySelector('.search-typeahead-v2__hit') || 
                                     document.querySelector('[role="option"]');
                    if (firstOption) {
                        firstOption.click();
                    }
                });
            } catch (error) {
                // console.log(`No autocomplete options appeared for ${id}, continuing...`);
            }
        } else {
            // Handle regular text input
            await page.$eval(`#${id}`, (el) => el.value = '');
            await page.type(`#${id}`, value.toString());
        }
        
        // Verify the value was set
        const finalValue = await page.$eval(`#${id}`, el => el.value);
        if (!finalValue.includes(value.toString())) {
            throw new Error(`Value verification failed for ${id}`);
        }
        
        // console.log(`Successfully filled text field ${id}`);
    } catch (error) {
        // console.log(`Error in fillText for ${id}: ${error.message}`);
        throw error;
    }
}

async function fillSelect(page, id, value) {
    try {
        // console.log(`Filling select field ${id} with value: ${value}`);
        
        // Wait for the select element
        await page.waitForSelector(`#${id}`, { timeout: 5000 });
        
        // Select the value
        await page.select(`#${id}`, value);
        
        // Verify the selection
        const selectedValue = await page.$eval(`#${id}`, el => el.value);
        if (selectedValue !== value) {
            throw new Error(`Value verification failed for ${id}`);
        }
        
        // console.log(`Successfully filled select field ${id}`);
    } catch (error) {
        // console.log(`Error in fillSelect for ${id}: ${error.message}`);
        throw error;
    }
}


async function fillRadio(page, formElementId, value) {
    try {
        // console.log(`Filling radio button with formElementId: ${formElementId} and value: ${value}`);
        
        // Use page.evaluate to execute JavaScript in the page's context
        await page.evaluate((formElementId, value) => {
            // Find all radio buttons in the form element
            const radioButtons = document.querySelectorAll(`[id="${formElementId}"] input[type="radio"]`);
            
            // Loop through radio buttons and select the one matching the value
            radioButtons.forEach(radio => {
                if (radio.value === value) {
                    radio.checked = true;
                    // Trigger change event to ensure form validation updates
                    radio.dispatchEvent(new Event('change', { bubbles: true }));
                }
            });
        }, formElementId, value);

        // console.log(`Successfully filled radio button with value: ${value}`);
    } catch (error) {
        // console.log(`Error in fillRadioButton: ${error.message}`);
        throw error;
    }
}
async function fillCheckbox(page, labelText, select = true) {
    try {
      // Find the checkbox containers (assuming it's identified by 'data-test-checkbox-form-component="true"')
      const components = await page.$$('fieldset[data-test-checkbox-form-component="true"]');
      let filled = false;
  
      for (const component of components) {
        // Look for the checkboxes inside the component
        const checkboxes = await component.$$('input[type="checkbox"]');
  
        for (const checkbox of checkboxes) {
          // Get the label text for each checkbox
          const label = await component.$(`label[for="${await checkbox.getProperty('id').then(id => id.jsonValue())}"]`);
          const labelTextContent = await label.evaluate(el => el.textContent.trim());
  
          // If label matches the target labelText
          if (labelTextContent === labelText) {
            const isChecked = await checkbox.evaluate(el => el.checked);
  
            // If the checkbox is not in the desired state, click it
            if (isChecked !== select) {
              await checkbox.click();
              filled = true;
            }
          }
        }
      }
  
      return filled;
    } catch (error) {
      console.error('Error filling checkbox:', error);
      return false;
    }
  }

  async function fillFormElements(page, formData) {
    try {
        console.log('Starting to fill form elements...', formData);
        
        for (const { id, value, type } of formData) {
            // Add variable delay between form fields
            const fieldDelay = Math.floor(Math.random() * 1000) + 500;
            await delay(fieldDelay);
            
            switch (type) {
                case 'text':
                case 'textarea':
                    await fillText(page, id, value);
                    break;
                case 'select':
                    await fillSelect(page, id, value);
                    break;
                case 'radio':
                    // If value is an array, iterate over the array and fill the radio buttons
                    if (Array.isArray(value)) {
                        for (const radioValue of value) {
                            await fillRadio(page, id, radioValue);
                        }
                    } else {
                        await fillRadio(page, id, value);
                    }
                    break;
                case 'checkbox':
                    // If value is an array, iterate over the array and check each checkbox
                    if (Array.isArray(value)) {
                        for (const checkboxValue of value) {
                            await fillCheckbox(page, checkboxValue);
                        }
                    } else {
                        await fillCheckbox(page, value);
                    }
                    break;
                default:
                    console.log(`Unsupported element type: ${type}`);
            }
        }
        
        console.log('Successfully filled all form elements');
    } catch (error) {
        console.log(`Error in fillFormElements: ${error.message}`);
        throw error;
    }
}



module.exports = {
    uploadResume,
    fillFormElements
};
