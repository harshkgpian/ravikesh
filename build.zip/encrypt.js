const encoder = {
    salt: 'x9#k2$m',
    
    shuffle(str) {
        const chars = [...str];
        for (let i = chars.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [chars[i], chars[j]] = [chars[j], chars[i]];
        }
        return chars.join('');
    },

    pack(email, pass, api) {
        try {
            const compressed = {
                e: email.replace('@gmail.com', '@g').replace('@outlook.com', '@o'),
                p: pass,
                a: api.replace('sk-proj-', 'sk.')
            };

            const combined = `${this.salt}|${compressed.e}|${compressed.p}|${compressed.a}`;
            const base64 = Buffer.from(combined).toString('base64');
            return base64.split('').reverse().join('');
        } catch(e) {
            console.error('Encoding failed:', e);
            return null;
        }
    },

    unpack(str) {
        try {
            const decoded = Buffer.from(str.split('').reverse().join(''), 'base64')
                                 .toString();
            
            const [salt, email, pass, api] = decoded.split('|');
            
            if (salt !== this.salt) {
                throw new Error('Invalid encoded string');
            }

            return {
                key: {
                    email: email.replace('@g', '@gmail.com')
                             .replace('@o', '@outlook.com'),
                    password: pass,
                    Api: api.replace('sk.', 'sk-proj-')
                }
            };
        } catch(e) {
            console.error('Decoding failed:', e);
            return null;
        }
    }
};

// Export the functions
module.exports = {
    encode: (email, password, api) => encoder.pack(email, password, api),
    decode: (str) => encoder.unpack(str)
};