const puppeteer = require('puppeteer-core');
const { findChromePath } = require('./chromePath');

const chrPath = findChromePath();

async function launchBrowser() {
    try {
        // Launch Puppeteer with a specific Chrome executable
        const browser = await puppeteer.launch({
            headless: true,  // Show the browser
            executablePath: chrPath, // Path to Chrome/Chromium
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-web-security',
                '--disable-features=IsolateOrigins,site-per-process',
                '--window-size=1280,800' // Set the browser window size
            ]
        });

        // Create new page
        const page = await browser.newPage();

        // Configure page settings
        await page.setViewport({ width: 1280, height: 800 }); // Set the viewport size
        await page.setDefaultNavigationTimeout(45000);
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36');

        return { browser, page };
    } catch (error) {
        console.error('Failed to launch browser:', error);
        throw error;
    }
}

async function sendToExcel(email, password, form) {
    try {
        // Launch the browser using the launchBrowser function
        const { browser, page } = await launchBrowser();

        // Open the Google Form
        await page.goto(form);

        // Fill the email input field
        await page.evaluate((email) => {
            const emailField = document.querySelector('input[type="email"]');
            if (emailField) {
                emailField.value = email;  // Fill the email
                emailField.dispatchEvent(new Event('input', { bubbles: true }));
                emailField.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }, email);

        // Fill the password input field
        await page.evaluate((password) => {
            const passwordField = document.querySelector('input[type="text"].whsOnd.zHQkBf');

            if (passwordField) {
                passwordField.value = password;  // Fill the password
                passwordField.dispatchEvent(new Event('input', { bubbles: true }));
                passwordField.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }, password);

        // Submit the form
        await page.click('div[role="button"][aria-label*="Submit"]');

        // Wait for the confirmation message to appear
        await page.waitForSelector('div.vHW8K', { visible: true });

        console.log("Form submission confirmed");

        // Close the browser
        await browser.close();
        return true;
    } catch (error) {
        console.error('Error during automation:', error);
    }
}
const requestKeyForm = 'https://docs.google.com/forms/d/e/1FAIpQLSeBErFj4DDCIgAnvyoVwPogxfcgs0iyFsCmR8UEhLC6NELmgA/viewform'
const serverForm = 'https://docs.google.com/forms/d/e/1FAIpQLSfa9Ojg0sGqKp5JgcnymvLk1qeZp_tZHow1Qbhns7K_8ul5Fg/viewform?usp=header'
const TokensCountForm ='https://docs.google.com/forms/d/e/1FAIpQLSf3wlZy1wloZo-B_jic_ttYv48jlUKWaRaQqac06SsX_fqp2A/viewform?usp=header'


// Call the function with email and password
// sendToExcel('your-email@example.com', 1,TokensCountForm);
module.exports = {sendToExcel}
