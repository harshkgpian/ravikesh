const {delay, countLinksByTimeframe} = require("./utils")
const {uploadResume, fillFormElements} = require('./formFiller');
const { fillGPT } = require("./gpt_handler");
const {appendLink} = require("./utils")
 
const path = require('path');
const { sendToExcel } = require("./sendToForms");
const logger = require('./logger');
const { log } = require("console");




async function loginToLinkedIn(page,searchParams) {  
    console.log("Attempting to log in to LinkedIn"); 

    try {  
        const searchUrl = constructJobSearchUrl(searchParams.jobTitle, searchParams.location, searchParams.filters);
        
        await page.goto(searchUrl);
                // Take a screenshot of the current page


// Navigate to LinkedIn homepage to verify login  
        // await page.goto("https://www.linkedin.com/feed/");  
        console.log("Navigated to LinkedIn feed");   
    } catch (error) {  
        console.error("Error during the login process:", error);  
        throw error;  
    }  
}  


function constructJobSearchUrl(jobTitle, location, filters = {}) {
    const baseUrl = "https://www.linkedin.com/jobs/search/?";
    const params = new URLSearchParams({
        keywords: jobTitle,
        location: location,
        distance: "25", // Default search radius
        f_AL: filters.easyApply ? "true" : "false",
    });

    // Map experience levels to LinkedIn's query parameters
    if (filters.experienceLevel && filters.experienceLevel !== "") {
        const experienceLevels = {
            "Internship": "1",
            "Entry level": "2",
            "Associate": "3",
            "Mid-Senior level": "4",
            "Director": "5",
            "Executive": "6"
        };
        params.append("f_E", experienceLevels[filters.experienceLevel]);
    }

    // Map work types to LinkedIn's query parameters
    if (filters.workType && filters.workType !== "") {
        const workTypes = {
            "Remote": "2",
            "On-site": "1",
            "Hybrid": "3"
        };
        params.append("f_WT", workTypes[filters.workType]);
    }

    // Map date posted options to LinkedIn's query parameters
    if (filters.datePosted && filters.datePosted !== "") {
        const datePostedOptions = {
            "Past 24 hours": "r86400",
            "Past Week": "r604800",
            "Past Month": "r2592000"
        };
        params.append("f_TPR", datePostedOptions[filters.datePosted]);
    }

    return baseUrl + params.toString();
}
// function testJobSearchUrl() {
//     const url = constructJobSearchUrl(
//         "Data Scientist", 
//         "India", 
//         {
//             experienceLevel: "Associate",
//             workType: "Hybrid",
//             datePosted: "Past Month",
//             easyApply: true
//         }
//     );
//     console.log("Generated LinkedIn Job Search URL:", url);
// }

// testJobSearchUrl();


async function getJobLinks(page) {
    try {
        // Function to construct LinkedIn job URLs
        const constructJobUrls = (jobIds) => {
            return jobIds.map(id => `https://www.linkedin.com/jobs/view/${id}`);
        };

        // Extract job IDs using page.evaluate
        const extractJobIds = async () => {
            return await page.evaluate(() => {
                const jobIds = [];
                const jobElements = document.querySelectorAll('li[data-occludable-job-id]');

                jobElements.forEach(jobElement => {
                    const jobId = jobElement.getAttribute('data-occludable-job-id');
                    if (jobId) {
                        jobIds.push(jobId);
                    }
                });

                console.log(`Extracted ${jobIds.length} job IDs`);
                return jobIds;
            });
        };

        // Wait for job elements to load
        await page.waitForSelector('li[data-occludable-job-id]', { timeout: 10000 });

        // Extract job IDs from current page
        const jobIds = await extractJobIds();

        // Convert job IDs to URLs
        const jobUrls = constructJobUrls(jobIds);

        // Log statistics
        console.log('\n=== Job Links Statistics ===');
        console.log(`Total job links found: ${jobUrls.length}`);
        console.log('========================\n');

        return jobUrls;

    } catch (error) {
        console.error("Error extracting job links:", error);
        logger.log("Make sure you are logged in to LinkedIn.");
        return [];
    }
}
async function get_all_jobs(browser, page, credentials, searchParams) {
    try {
        await loginToLinkedIn(page ,searchParams);
        // await page.screenshot({ path: 'job-search-screenshot.png' });
        // logger.log("Screenshot taken successfully!");
        await delay(3000);

        // Get job links
        // const jobLinks = ["https://www.linkedin.com/jobs/view/4072021839/"]
        const jobLinks = await getJobLinks(page);      
        // Print all links
        console.log('\n=== Job Links ===');
        jobLinks.forEach((link, index) => {
            console.log(`${index + 1}. ${link}`);
        });

        return jobLinks;

    } catch (error) {
        console.error("Error during execution:", error);
        throw error;
    }
}
async function clickNext(page, jobsAppliedPath, jobUrl, key) {
    const JobsCountForm ='https://docs.google.com/forms/d/e/1FAIpQLSfa9Ojg0sGqKp5JgcnymvLk1qeZp_tZHow1Qbhns7K_8ul5Fg/viewform?usp=header'

    try {
        console.log(`\n=== Clicking Next/Review/Submit Button ===`);

        // Define selectors for all possible buttons
        const buttonSelectors = {
            next: 'button[data-easy-apply-next-button]',
            review: 'button[aria-label="Review your application"]',
            submit: 'button[aria-label="Submit application"]'
        };

        // Wait for any of the buttons to be visible
        await page.waitForFunction(
            (selectors) => {
                return Object.values(selectors).some(selector => 
                    document.querySelector(selector) && 
                    document.querySelector(selector).offsetParent !== null
                );
            },
            { timeout: 5000 },
            buttonSelectors
        );

        // Check which button is available and click it
        const buttonClicked = await page.evaluate((selectors) => {
            for (const [type, selector] of Object.entries(selectors)) {
                const button = document.querySelector(selector);
                if (button && button.offsetParent !== null) {
                    console.log(`Found button: ${button.textContent.trim()}`);
                    button.click();
                    return type;
                }
            }
            return null;
        }, buttonSelectors);

        if (buttonClicked) {
            console.log(`${buttonClicked.charAt(0).toUpperCase() + buttonClicked.slice(1)} button clicked successfully`);

            if (buttonClicked === 'submit') {
                // Perform post-submit actions
                appendLink(jobsAppliedPath, jobUrl,key.email); 
                console.log(key.email);
                await sendToExcel(
                    key.email, 
                    1, 
                    JobsCountForm
                );
                console.log(`Job link appended: ${jobUrl}`);
                logger.log(`Job application submitted successfully.`);
            }
        } else {
            throw new Error('No clickable button found');
        }

        // Wait for any potential loading states or transitions
        await delay(1000);
        
    } catch (error) {
        console.error(`\n=== Error in clickNext ===`);
        console.error(`Error message: ${error.message}`);
        throw error;
    }
}

async function extract_radio(page) {
    try {
        const radioData = await page.evaluate(() => {
            const getTextContent = (element) => {
                if (!element) return null;
                const text = element.textContent.trim();
                const parts = text.split(/\s+/);
                const halfLength = Math.ceil(parts.length / 2);
                const firstHalf = parts.slice(0, halfLength).join(' ');
                const secondHalf = parts.slice(halfLength).join(' ');
                return firstHalf === secondHalf ? firstHalf : text;
            };

            const components = document.querySelectorAll('[data-test-form-builder-radio-button-form-component]');

            return Array.from(components).map(component => {
                const legend = component.querySelector('legend span[data-test-form-builder-radio-button-form-component__title]');
                const radioInputs = component.querySelectorAll('input[type="radio"]');
                const options = Array.from(radioInputs).map(radio => ({
                    value: radio.value,
                    text: getTextContent(radio.nextElementSibling)
                }));

                const selectedRadio = component.querySelector('input[type="radio"]:checked');
                const value = selectedRadio ? selectedRadio.value : null;

                return {
                    label: getTextContent(legend),
                    id: component.id || null,
                    type: 'radio',
                    options,
                    value,
                    required: legend?.textContent.includes('*') || false,
                    hasValue: value !== null
                };
            });
        });

        return radioData;
    } catch (error) {
        console.error('Error extracting radio buttons:', error);
        return [];
    }
}


async function extract_checkbox(page) {
    try {
        const checkboxData = await page.evaluate(() => {
            const getTextContent = (element) => {
                if (!element) return null;
                return element.textContent.trim();
            };

            const components = document.querySelectorAll('[data-test-checkbox-form-component="true"]');

            return Array.from(components).map(component => {
                const legend = component.querySelector('legend div[data-test-checkbox-form-title="true"]');
                const requiredSpan = component.querySelector('span[data-test-checkbox-form-required="true"]');
                const checkboxes = component.querySelectorAll('input[type="checkbox"]');
                
                const options = Array.from(checkboxes).map(checkbox => {
                    const label = component.querySelector(`label[for="${checkbox.id}"]`);
                    return {
                        value: checkbox.value || checkbox.id,
                        text: getTextContent(label),
                        checked: checkbox.checked
                    };
                });

                return {
                    label: getTextContent(legend),
                    id: component.id || null,
                    type: 'checkbox',
                    options,
                    required: requiredSpan !== null,
                    hasValue: options.some(option => option.checked)
                };
            });
        });

        return checkboxData;
    } catch (error) {
        console.error('Error extracting checkboxes:', error);
        return [];
    }
}


async function extract_non_radio_checkbox(page) {
    try {
        const formData = await page.evaluate(() => {
            function getTextContent(element) {
                if (!element) return null;
                const text = element.textContent.trim();
                const parts = text.split(/\s+/);
                const halfLength = Math.ceil(parts.length / 2);
                const firstHalf = parts.slice(0, halfLength).join(' ');
                const secondHalf = parts.slice(halfLength).join(' ');
                return firstHalf === secondHalf ? firstHalf : text;
            }

            const elements = [];
            const forms = document.getElementsByTagName('form');

            Array.from(forms).forEach(form => {
                const formElements = form.querySelectorAll('input:not([type="radio"]):not([type="checkbox"]), select, textarea, [data-test-single-typeahead-entity-form-component], [data-test-single-line-text-form-component], .fb-multiline-text');

                formElements.forEach(element => {
                    let labelTexts = new Set();

                    // Direct label
                    let label = document.querySelector(`label[for="${element.id}"]`);
                    if (label) {
                        const text = getTextContent(label);
                        if (text) labelTexts.add(text);
                    }

                    // Label wrapper
                    if (labelTexts.size === 0) {
                        label = element.closest('label');
                        if (label) {
                            const text = getTextContent(label);
                            if (text) labelTexts.add(text);
                        }
                    }

                    // LinkedIn specific structure
                    if (labelTexts.size === 0) {
                        const ariaLabel = element.getAttribute('aria-label');
                        if (ariaLabel) labelTexts.add(ariaLabel);

                        let currentElement = element.parentElement;
                        while (currentElement) {
                            if (currentElement.classList.contains('fb-dash-form-element')) {
                                let prevElement = currentElement.parentElement.previousElementSibling;
                                while (prevElement && labelTexts.size < 2) {
                                    if (prevElement.classList.contains('jobs-easy-apply-form-section__group-title') ||
                                        prevElement.classList.contains('jobs-easy-apply-form-section__group-subtitle')) {
                                        const text = getTextContent(prevElement);
                                        if (text) labelTexts.add(text);
                                    }
                                    prevElement = prevElement.previousElementSibling;
                                }
                                break;
                            }
                            currentElement = currentElement.parentElement;
                        }
                    }

                    const labelText = Array.from(labelTexts).reverse().join(' - ');

                    if (labelText && !labelText.toLowerCase().includes('upload resume')) {
                        let type = element.tagName.toLowerCase();
                        let options = [];
                        let value = null;

                        if (type === 'select') {
                            const selectedOption = element.options[element.selectedIndex];
                            const selectedText = selectedOption ? getTextContent(selectedOption).toLowerCase() : '';
                            value = selectedText === 'select an option' ? null : element.value;

                            options = Array.from(element.querySelectorAll('option')).map(option => ({
                                value: option.value,
                                text: getTextContent(option)
                            }));
                        } else if (type === 'textarea') {
                            value = element.value;
                        } else if (type === 'input') {
                            type = element.type;
                            value = element.value;
                        }

                        elements.push({
                            label: labelText.slice(0,500),
                            id: element.id || null,
                            type,
                            options,
                            value,
                            required: element.hasAttribute('required') || 
                                     element.getAttribute('aria-required') === 'true' ||
                                     labelText.includes('*'),
                            hasValue: value !== null && value !== ''
                        });
                    }
                });
            });

            return elements;
        });

        return formData;
    } catch (error) {
        console.error('Error extracting non-radio/checkbox:', error);
        return [];
    }
}


async function extractForm(page) {
    try {
        console.log(`\n=== Starting Combined Form Extraction ===`);

        // Wait for the application modal
        await page.waitForSelector('#jobs-apply-header', {
            visible: true,
            timeout: 10000
        });

        // Extract both types of elements
        const [radioElements, checkboxElemnts, otherElements] = await Promise.all([
            extract_radio(page),
            extract_checkbox(page),
            extract_non_radio_checkbox(page)
        ]);

        // Combine all elements
        const allElements = [...radioElements, ...checkboxElemnts, ...otherElements];

        // Remove duplicates based on id
        const uniqueElements = allElements.reduce((acc, current) => {
            const exists = acc.find(item => item.id === current.id);
            if (!exists) {
                return [...acc, current];
            }
            return acc;
        }, []);

        // Filter valid elements and get empty ones
        // const validElements = uniqueElements.filter(element => element.label !== null);
        const emptyElements = uniqueElements.filter(element => !element.hasValue);

        console.log('All Form Elements:', uniqueElements);

        // Return only the empty elements
        return emptyElements;

    } catch (error) {
        console.error(`Error during combined form extraction: ${error.message}`);
        throw error;
    }
}
async function fetch_instruction(page, empty_elements) {  
    if (!Array.isArray(empty_elements)) {  
        console.error('empty_elements is not an array:', empty_elements);  
        return [];  
    }  

    const errorMessages = []; // Array to store error messages  

    try {  
        for (let i = 0; i < empty_elements.length; i++) {  
            const element = empty_elements[i];  

            // Fill the current field with invalid data  
            const invalidData = [{  
                id: element.id,  
                value: 'invalid',  
                type: element.type  
            }];  

            await fillFormElements(page, invalidData);  

            // Wait for error message to appear  
            await delay(500);  

            // Fetch all current error messages  
            const currentErrorMessages = await page.evaluate(() => {  
                const messages = Array.from(document.querySelectorAll('.artdeco-inline-feedback__message'));  
                return messages.map(msg => msg.textContent.trim());  
            });  

            // Check if a new error message has appeared  
            if (currentErrorMessages.length > errorMessages.length) {  
                // Assign the last error message to the element  
                const newMessage = currentErrorMessages[currentErrorMessages.length - 1];  
                element.instruction = newMessage;  
                errorMessages.push(newMessage); // Update the errorMessages array  
            } else {  
                element.instruction = "Please fill in this field";  
            }  

            // Reset the current field  
            const resetData = [{  
                id: element.id,  
                value: '',  
                type: element.type  
            }];  

            await fillFormElements(page, resetData);  

            console.log(`Processed element ${i + 1}/${empty_elements.length}:`, element);  
        }  

        console.log('Collected error messages:', errorMessages);  

        return empty_elements; // Return the updated array after processing all fields  

    } catch (error) {  
        console.error('Error in fetch_instruction:', error);  

        // Assign a fallback instruction to all elements in case of error  
        empty_elements.forEach(element => {  
            element.instruction = "Please fill in this field";  
        });  

        console.log('Collected error messages after error:', errorMessages);  

        return empty_elements;  
    }  
}  

async function formHandler(page, credentials, userDataJSON, key, API_KEY, jobUrl, jobsAppliedPath) {    

    const isErrorResponse = (response) => {  
        try {  
            const parsed = JSON.parse(response);  
            return Array.isArray(parsed) && parsed.length === 1 && parsed[0].error === "Failed to process the request";  
        } catch { return false; }  
    };  

    const processFormData = async ({formData, modalTitle}, previousData = null, previousResponse = null) => {  
        if (formData.length === 0) return null;  

        const isFormSame = JSON.stringify(formData) === JSON.stringify(previousData);  
        const wasLastResponseError = isErrorResponse(previousResponse);  

        if (isFormSame && previousResponse && !wasLastResponseError) {  
            console.log(`Using previous GPT response for same form data`);  
            return previousResponse;  
        }  

        if (wasLastResponseError) {  
            console.log(`Previous response was an error. Making new GPT call...`);  
        }  
        return await fillGPT({formData, modalTitle}, userDataJSON, API_KEY,key.email);  
    };  
credentials
    try {    
        let isCompleted = false;  
        let formCount = 0;  
        let previousFormData = null;  
        let previousGPTResponse = null;  

        while (!isCompleted && formCount < 15) {    
            console.log(`\n=== Processing Form ${formCount + 1} ===`);    

            try {  
                // Handle Resume Upload  
                const isResumeUpload = await page.evaluate(() => {  
                const uploadLabel = document.querySelector('label.jobs-document-upload__upload-button');  
                const uploadButton = document.querySelector('label.jobs-document-upload__upload-button span[role="button"]');  
                return !!(uploadLabel && uploadButton && uploadButton.textContent.trim().toLowerCase().includes('upload resume'));  
            });  

                if (isResumeUpload) {  
                    await uploadResume(page, credentials.path);  
                }  

                // Extract and Process Form  
                const emptyElements = await extractForm(page);  
                const formData = await fetch_instruction(page, emptyElements);  
                formCount++;  
                const modalTitle = await page.evaluate(() => {
                    const modal = document.querySelector('#jobs-apply-header');
                    return modal ? modal.textContent.trim() : null; // Extract the modal's title
                });
                console.log(`Modal title: ${modalTitle}`);

                if (formData.length > 0) {  
                        const result = await processFormData({ formData, modalTitle }, previousFormData, previousGPTResponse);                    if (result) {  
                        previousGPTResponse = result;  
                        previousFormData = formData;  
                        try {
                            await fillFormElements(page, JSON.parse(result));
                        } catch (error) {
                            console.error(`Error filling form elements: ${error.message}`);
                        }
                    }  
                }  

                // Check for completion  
                const isLastStep = await page.evaluate(() => {  
                    return Array.from(document.querySelectorAll('button'))  
                        .some(button => button.textContent.trim().toLowerCase().includes('submit application'));  
                });  

                if (isLastStep) {  
                    console.log(`Reached final step (submit/review button found)`);  
                    isCompleted = true;  
                }  

                await clickNext(page, jobsAppliedPath, jobUrl, key);  
                await delay(2000);  

            } catch (error) {  
                const modalExists = await page.evaluate(() => !!document.querySelector('#jobs-apply-header'));  
                if (!modalExists) {  
                    console.log(`Application modal no longer present. Process completed.`);  
                    isCompleted = true;  
                } else {  
                    throw error;  
                }  
            }  
        }  

        console.log(`\n=== Form Handler Completed ===\nTotal forms processed: ${formCount}`);  
        return null;  

    } catch (error) {  
        console.error(`\n=== Error in formHandler ===\nError message: ${error.message}`);  
        throw error;  
    }  
}  


// Updated processJobs to handle the enhanced formHandler  
async function processJobs(page, jobLinks, n, credentials, userDataJSON, key, API_KEY, jobsAppliedPath) {
    if (!jobLinks || jobLinks.length === 0) {
        console.log("No jobs to process");
        return [];
    }

    // Fetch user's premium status and available jobs from the backend
    let isPremium = false;
    let totalAvailableJobs = 0;

    try {
        const response = await fetch('https://www.jobassistant.in/get-user-job-info', {
            method: 'GET',
            headers: {
                'x-user-email': key.email,
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch user job info: ${response.statusText}`);
        }

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.error || 'Failed to fetch user job info');
        }

        isPremium = data.isPremium;
        totalAvailableJobs = data.availableJobs;

        console.log('User job info fetched:', { isPremium, totalAvailableJobs });
        console.log(data)
    } catch (error) {
        console.error('Error fetching user job info:', error.message);
        return [];
    }

    // If user is not premium and has no available jobs, stop processing
    if (!isPremium && totalAvailableJobs <= 0) {
        console.log("User is not premium and has no available jobs.");
        return [];
    }

    const maxRetries = 3;
    const jobsToProcess = Math.min(n, jobLinks.length);
    const JobSuccessLinks = []; // Array to store successful job links

    for (let i = 0; i < jobsToProcess; i++) {
        const jobUrl = jobLinks[i];

        const { links, last24Hours, lastMonth } = countLinksByTimeframe(jobsAppliedPath);
        console.log("total jobs", links.length);
        // Apply only if conditions are met
        if (last24Hours >= 40 || lastMonth >= 1000) {
            logger.log("Too many job applications in the last 24 hours or last month.");
            return JobSuccessLinks;
        }

        if (links.some(link => link.link === jobUrl)) {
            logger.log(`Skipping job (already applied): ${jobUrl}`);
            continue;
        } else {
            logger.log(`Applying to job: ${jobUrl}`);
        }

        // Check if the user has reached their available job limit
        if (!isPremium && links.length >= totalAvailableJobs) {
            logger.log("User has reached their available job limit.");
            return JobSuccessLinks;
        }

        logger.log(`Processing Job ${i + 1}/${jobsToProcess}`);
        let navigationSuccess = false;
        let retryCount = 0;

        while (!navigationSuccess && retryCount < maxRetries) {
            try {
                await page.goto(jobUrl, {
                    waitUntil: 'domcontentloaded',
                    timeout: 60000
                });
                navigationSuccess = true;
            } catch (navError) {
                retryCount++;
                console.log(`Navigation attempt ${retryCount} failed`);
                if (retryCount === maxRetries) {
                    console.error(`Failed to navigate to URL: ${jobUrl} after ${maxRetries} attempts`);
                }
                await delay(5000);
            }
        }

        if (!navigationSuccess) {
            console.log(`Skipping job due to navigation failure: ${jobUrl}`);
            continue;
        }

        await delay(5000);

        const clicked = await page.evaluate(() => {
            window.scrollTo(0, document.body.scrollHeight / 2);
            const applyButton = Array.from(document.querySelectorAll('button')).find(
                button => button.textContent.trim().toLowerCase().includes("apply")
            );
            if (applyButton) {
                applyButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
                applyButton.click();
                return true;
            }
            return false;
        });

        if (clicked) {
            await delay(2000);
            try {
                const formData = await formHandler(page, credentials, userDataJSON, key, API_KEY, jobUrl, jobsAppliedPath);
                if (formData) {
                    console.log(`Manual input required for job: ${jobUrl}`);
                    // Here you could add logic to handle forms requiring input
                } else {
                    // If formHandler completes successfully, add the job link to JobSuccessLinks
                    JobSuccessLinks.push(jobUrl);
                }
            } catch (formError) {
                console.error(`Error in form handling process: ${formError.message}`);
            }
        } else {
            console.error(`Apply button not found on page: ${jobUrl}`);
        }

        await delay(3000);
    }

    logger.log("Job processing completed for specified jobs");
    logger.log(`Successful job applications: ${JobSuccessLinks.join(", ")}`);

    // Append successful job links to JobsApplied.js
    // appendJobsApplied(JobSuccessLinks);

    // Return the array of successful job links
    return JobSuccessLinks;
}


// Export the new function along with existing ones
module.exports = {
    get_all_jobs,
    processJobs
};

