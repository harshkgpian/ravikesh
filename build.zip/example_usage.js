// example_usage.js
const { main } = require('./mainFiller');


// Export the main function to be used by Electron
async function executeAutomation(credentials, searchParams, userDataJSON, key ,API_KEY,customDataFolder) {
    try {
        console.log("Starting LinkedIn automation...");
        console.log("Using credentials:", credentials);
        console.log("Search parameters:", searchParams);
        console.log("User Data JSON parameters:", userDataJSON);

        
        await main(credentials, searchParams, userDataJSON, key , API_KEY,customDataFolder);
        
        console.log("LinkedIn automation completed successfully");
        return true;
    } catch (error) {
        console.error("Error in LinkedIn automation:", error);
        throw error; // Rethrow to be handled by the main process
    }
}

module.exports = {
    main: executeAutomation
};

// Only run the self-executing function if this file is run directly
if (require.main === module) {
    // This will only run if example_usage.js is executed directly
    const { credentials, searchParams, userDataJSON} = require('./sample_user_data');
    
    (async () => {
        try {
            console.log("Starting example usage of the main script...");
            await executeAutomation(credentials, searchParams ,userDataJSON, key,API_KEY);
            console.log("Example usage complete.");
        } catch (error) {
            console.error("Error occurred in example_usage.js:", error);
        }
    })();
}