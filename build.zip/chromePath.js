const fs = require('fs');  
const path = require('path');  

// Function to find Chrome executable path  
function findChromePath() {  
    const platform = process.platform;  

    if (platform === 'win32') {  
        // Windows paths  
        const winPaths = [  
            process.env.LOCALAPPDATA + '\\Google\\Chrome\\Application\\chrome.exe',  
            process.env.PROGRAMFILES + '\\Google\\Chrome\\Application\\chrome.exe',  
            process.env['PROGRAMFILES(X86)'] + '\\Google\\Chrome\\Application\\chrome.exe'  
        ];  

        for (const chromePath of winPaths) {  
            if (fs.existsSync(chromePath)) {  
                return chromePath;  
            }  
        }  
    } else if (platform === 'darwin') {  
        // macOS path  
        const macPath = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';  
        if (fs.existsSync(macPath)) {  
            return macPath;  
        }  
    } else if (platform === 'linux') {  
        // Linux paths  
        const linuxPaths = [  
            '/usr/bin/google-chrome',  
            '/usr/local/bin/google-chrome',  
            '/opt/google/chrome/google-chrome'  
        ];  

        for (const chromePath of linuxPaths) {  
            if (fs.existsSync(chromePath)) {  
                return chromePath;  
            }  
        }  
    }  

    return 'Chrome not found';  
}  

// Example usage  
const chromePath = findChromePath();  
console.log('Chrome Path:', chromePath);  
module.exports = {findChromePath}