const { ipcRenderer } = require('electron');

class FriendlyServer {
    constructor() {
        this.startTime = Date.now();
        
        this.elements = {
            closeBtn: document.getElementById('closeApp'),
            uptimeDisplay: document.getElementById('uptimeDisplay')
        };
        
        this.initializeEventListeners();
        this.startUptime();
    }

    initializeEventListeners() {
        this.elements.closeBtn.addEventListener('click', () => {
            ipcRenderer.send('close-server');
        });
    }

    startUptime() {
        this.updateUptime();
        setInterval(() => this.updateUptime(), 1000);
    }

    updateUptime() {
        const uptime = Math.floor((Date.now() - this.startTime) / 1000);
        const hours = Math.floor(uptime / 3600).toString().padStart(2, '0');
        const minutes = Math.floor((uptime % 3600) / 60).toString().padStart(2, '0');
        const seconds = (uptime % 60).toString().padStart(2, '0');
        
        this.elements.uptimeDisplay.textContent = `${hours}:${minutes}:${seconds}`;
    }
}

window.addEventListener('load', () => {
    new FriendlyServer();
});