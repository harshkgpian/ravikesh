const puppeteer = require('puppeteer');
const fs = require('fs').promises;
const path = require('path');
const { exec } = require('child_process');
const { get_all_jobs, processJobs } = require("./formHandler");
const { findChromePath } = require('./chromePath');
const { appendLinks } = require("./utils");
const { fetchData } = require('./fetchData.js');
const logger = require('./logger');
const os = require('os');

const CHROME_DEBUG_PORT = 9222;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function isDebugPortAvailable(port) {
    try {
        const response = await fetch(`http://127.0.0.1:${port}/json/version`);
        const data = await response.json();
        return !!data.webSocketDebuggerUrl;
    } catch (error) {
        return false;
    }
}

async function closeLinkedInTabs(browser) {
    const pages = await browser.pages();
    for (const page of pages) {
        try {
            const url = await page.url();
            if (url.includes('linkedin.com')) {
                await page.close();
                console.log('Closed LinkedIn tab:', url);
            }
        } catch (error) {
            console.log('Error checking page URL:', error);
        }
    }
}

async function gracefullyCloseChrome() {
    return new Promise((resolve) => {
        const command = process.platform === 'win32' 
            ? 'taskkill /IM chrome.exe /F'
            : 'pkill -TERM chrome';
            
        exec(command, async () => {
            await sleep(2000);
            resolve();
        });
    });
}

async function openChrome() {
    try {
        // Always close existing Chrome instances first
        await gracefullyCloseChrome();
        await sleep(2000);

        const chromePath = await findChromePath();
        if (!chromePath) {
            throw new Error('Could not find Chrome installation');
        }

        const chromeFlags = [
            `--remote-debugging-port=${CHROME_DEBUG_PORT}`,
            '--profile-directory="Default"',
            '--no-first-run',
            '--no-default-browser-check',
            '--disable-popup-blocking',
            '--disable-sync',
            '--no-experiments',
            '--disable-background-timer-throttling',
            '--disable-backgrounding-occluded-windows',
            '--disable-renderer-backgrounding',
            '--disable-background-networking',
            '--disable-background-tabs',
            '--disable-background-mode',
            '--disable-background-downloads',
            '--start-maximized',
            '--disable-features=TranslateUI',
            '--disable-breakpad',
            '--noerrdialogs',
            '--disable-hang-monitor',
            '--disable-client-side-phishing-detection',
            '--disable-component-update',
            '--disable-zero-browsers-open-for-tests',
            '--ignore-certificate-errors',
            '--use-fake-ui-for-media-stream',
            '--enable-automation',
            '--disable-wake-on-wifi',
            '--disable-features=OptimizationHints',
            '--disable-features=IsolateOrigins',
            '--disable-site-isolation-trials'
        ];

        const command = `"${chromePath}" ${chromeFlags.join(' ')}`;
        exec(command);
        
        // Wait for Chrome to fully initialize
        await sleep(5000);
        
        return true;
    } catch (error) {
        console.error('Failed to launch Chrome:', error);
        throw error;
    }
}

async function getChromeWebSocketUrl(retries = 5, delay = 2000) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await fetch(`http://127.0.0.1:${CHROME_DEBUG_PORT}/json/version`);
            const data = await response.json();
            if (data.webSocketDebuggerUrl) {
                console.log('WebSocket URL:', data.webSocketDebuggerUrl);
                return data.webSocketDebuggerUrl;
            }
        } catch (error) {
            console.log(`Attempt ${i + 1}/${retries}: Waiting for Chrome to initialize...`);
            await sleep(delay);
        }
    }
    throw new Error('Failed to get WebSocket URL after multiple attempts');
}

async function launchBrowser(wsEndpoint) {
    try {
        const browser = await puppeteer.connect({
            browserWSEndpoint: wsEndpoint,
            defaultViewport: null
        });

        // Close any existing LinkedIn tabs
        await closeLinkedInTabs(browser);
        
        const pages = await browser.pages();
        console.log(`Connected to browser with ${pages.length} existing pages`);
        
        return { browser };
    } catch (error) {
        console.error('Failed to connect to the browser:', error);
        throw error;
    }
}

async function main(credentials, searchParams, userDataJSON, key, API_KEY, customDataFolder) {
    const jobsAppliedPath = path.join(customDataFolder, 'jobsApplied.js');
    const allJobsPath = path.join(customDataFolder, 'allJobs.js');
    console.log("key", key);

    try {
        let wsEndpoint;

        // Check if the Chrome debug port is available
        const debugPortAvailable = await isDebugPortAvailable(CHROME_DEBUG_PORT);

        if (debugPortAvailable) {
            console.log("Debug port is available, proceeding without restarting Chrome...");
            wsEndpoint = await getChromeWebSocketUrl();
        } else {
            console.log("Debug port not available, restarting Chrome...");
            await openChrome();
            console.log('Chrome opened with remote debugging mode enabled.');
            await sleep(3000); // Wait for Chrome to initialize
            wsEndpoint = await getChromeWebSocketUrl();
        }

        const stats = await fetchData(key.email);

        try {
            let browser, page;
            try {
                logger.log("Starting LinkedIn job search...");
                logger.log(`Searching for: ${searchParams.jobTitle} in ${searchParams.location}`);

                const browserInstance = await launchBrowser(wsEndpoint);
                browser = browserInstance.browser;

                // Create a new tab for the job search
                page = await browser.newPage();

                const jobLinks = await get_all_jobs(browser, page, credentials, searchParams);
                logger.log(`Found ${jobLinks.length} jobs`);

                appendLinks(allJobsPath, jobLinks);
                await processJobs(page, jobLinks, 25, credentials, userDataJSON, key, API_KEY, jobsAppliedPath);

            } catch (error) {
                console.error("Error in main process:", error);
                console.log(`❌ Error: ${error.message}`);
            } finally {
                if (browser) {
                    await browser.disconnect();
                    console.log("Browser disconnected");
                }
            }
        } catch (error) {
            if (error.code === 'ENOENT') {
                console.error(`File not found: ${jobsAppliedPath}`);
                await fs.writeFile(jobsAppliedPath, '[]');
                console.log(`Created new ${jobsAppliedPath} file`);
            } else {
                throw error;
            }
        }

    } catch (error) {
        console.error("Error in stats check:", error);
        console.log("❌ An error occurred while checking application limits.");
    }
}


process.on('SIGINT', async () => {
    console.log('Closing Chrome and exiting...');
    // await gracefullyCloseChrome();
    process.exit(0);
});

module.exports = { main };