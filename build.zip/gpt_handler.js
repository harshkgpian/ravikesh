const axios = require('axios');
const { sendToExcel } = require("./sendToForms");
const logger = require('./logger');




class OpenAIAPI {
  constructor(apiKey,email) {
    this.apiKey = apiKey;
    this.email = email;

    this.baseUrl = "https://api.openai.com/v1";
    this.headers = {
      "Authorization": `Bearer ${this.apiKey}`,
      "Content-Type": "application/json"
    };
  }

  async chatCompletion(messages, model = "gpt-4o-mini-2024-07-18") {
    const endpoint = `${this.baseUrl}/chat/completions`;
    
    const payload = {
      model: model,
      messages: messages,
      temperature: 0.1
    };
    
    try {
      const response = await axios.post(endpoint, payload, { headers: this.headers });
      const TokensCountForm ='https://docs.google.com/forms/d/e/1FAIpQLSf3wlZy1wloZo-B_jic_ttYv48jlUKWaRaQqac06SsX_fqp2A/viewform?usp=header'

      const tokensUsed = response.data.usage.total_tokens || 0;
      await sendToExcel(
        this.email, 
        tokensUsed, 
        TokensCountForm
      );

      console.log(`Tokens: ${tokensUsed}, Cost: ${tokensUsed * 84 * 0.6 / 1000000} Rs`);
      return response.data;
    } catch (error) {
      console.error(`Error: ${error.message}`);
      return null;
    }
  }
}

async function fillGPT({formData, modalTitle}, userData, API_KEY, email) {
  // console.log("Calling GPT on", userData)`);
  // logger.log(`Calling GPT on ${modalTitle}`);
  
  const client = new OpenAIAPI(API_KEY,email);
    const prompt = `
    You are tasked with generating appropriate answers for form fields based on the provided form structure and user data.
    Your output should match the exact format of the result array. Also make sure answers are positive and help in getting a job.
    Always provide numerical values only for experience, notice period etc. Never put 0 in any experience.
    Some Labels can be null, it not an issue just choose from the option.
    
    **Job Title:**  
    ${modalTitle}
    

    **Form Structure:**
    ${JSON.stringify(formData)}
    
    **Instructions:**
    1. Generate a result array that matches each form field's ID exactly
    2. For each field:
       - Maintain the exact ID from formDetails
       - Include appropriate value based on field type
       - Include the field type (radio, input, or select)
    3. Values should be:
       - For input fields: Based on the instruction of the field.
       - For select/radio fields: One of the provided options
       - For checkboxes: one or more of the provided options, if multiple answers there, give them as ["value1", "value2"].
    
    **Expected Output Format:**
    [
        {
            "id": "<exact-id-from-form>",
            "value": "<appropriate-value>",
            "type": "<field-type>"
        },
        ...
    ]
    
    **User Data:**
    ${userData};
    .`;
    
    // The rest of your OpenAI API implementation remains the same...

    // console.log(prompt)

  try {
    const chatCompletion = await client.chatCompletion([
      {
        role: "system",
        content: "You are a form-filling assistant. Respond only with valid JSON arrays."
      },
      { role: "user", content: prompt }
    ]);

    const response = chatCompletion.choices[0].message.content.trim();
    // console.log(response)
    
    try {
        jsonResponse = JSON.parse(response);
        if (!Array.isArray(jsonResponse)) {
          jsonResponse = [jsonResponse];
        }
      } catch (error) {
        const jsonMatch = response.match(/\[.*\]/s);
        if (jsonMatch) {
          try {
            jsonResponse = JSON.parse(jsonMatch[0]);
          } catch (innerError) {
            jsonResponse = [{ error: "Failed to parse JSON response" }];
          }
        } else {
          jsonResponse = [{ error: "Failed to parse JSON response" }];
        }
      }
  
      return JSON.stringify(jsonResponse, null, 2);
    } catch (error) {
      console.error(`Error in fillGpt: ${error.message}`);
      return JSON.stringify([{ error: "Failed to process the request" }]);
    }
  }

  async function getUserInfoJson(resumeText, API_KEY, email) {
    console.log("GETAPI",API_KEY)
    const client = new OpenAIAPI(API_KEY, email);
    const prompt = `
  You are tasked with generating a compact, token-optimized JSON structure from the provided resume text. 
  The JSON should have these keys: personal, education, experience, projects, and skills.
  
  **Instructions:**
  1. Extract only relevant details while keeping the structure minimal.
  2. Use concise field names, remove unnecessary spaces, and avoid lengthy descriptions.
  
  **Resume Text:**
  ${resumeText}
  
  **Expected Output Format Example:**
  {
    personal:{name:"John Doe",email:"john@example.com"},
    education:{college:{name:"XYZ University",degree:"B.Tech",field:"CS",year:"2025"}},
    experience:[{company:"ABC Corp",role:"Intern",period:"Jun-Aug 2023",work:"Built APIs"}],
    projects:[{name:"ProjectX",tech:["Python","Flask"],desc:"Web app for task management"}],
    skills:{languages:["Python","C++"],tools:["Git","VS Code"],domains:["ML","Web Dev"]},
    CTC : {Current CTC: "800000", Expected CTC: "1200000"},
    NoticePeriod: {Notice Period: "30 days"}
  }
- Try to make it as concise as possible.`
  ;
  
    try {
      const chatCompletion = await client.chatCompletion([
        {
          role: "system",
          content: "You are a resume-to-JSON assistant. Respond only with valid JSON."
        },
        { role: "user", content: prompt }
      ]);
  
      const response = chatCompletion.choices[0].message.content.trim();
  
      let jsonResponse;
      try {
        jsonResponse = JSON.parse(response);
      } catch (error) {
        const jsonMatch = response.match(/\{.*\}/s);
        jsonResponse = jsonMatch ? JSON.parse(jsonMatch[0]) : { error: "Failed to parse JSON" };
      }
  
      return JSON.stringify(jsonResponse, null, 2);
    } catch (error) {
      console.error(`Error in getUserInfoJson: ${error.message}`);
      return JSON.stringify({ error: "Request processing failed" });
    }
  }
  


module.exports = {
  OpenAIAPI,
  fillGPT,
  getUserInfoJson
};