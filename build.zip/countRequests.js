const { exec } = require('child_process');
const { findChromePath } = require('./chromePath');

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function openChrome() {
    const chromePath = await findChromePath();
    if (!chromePath) {
        throw new Error('Could not find Chrome installation');
    }

    const command = `"${chromePath}" --remote-debugging-port=9222`;
    exec(command, (error, stderr) => {
        if (error) {
            console.error(`Error launching Chrome: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`stderr: ${stderr}`);
            return;
        }
    });
}

async function closeChrome() {
    return new Promise((resolve, reject) => {
        const command = process.platform === 'win32' 
            ? 'taskkill /F /IM chrome.exe' 
            : 'pkill -f chrome';

        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error('Failed to close Chrome:', error);
                reject(error);
                return;
            }
            console.log('Chrome closed successfully');
            resolve();
        });
    });
}

async function getChromeWebSocketUrl(retries = 5, delay = 1000) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await fetch('http://localhost:9222/json/version');
            const data = await response.json();
            
            if (data.webSocketDebuggerUrl) {
                return data.webSocketDebuggerUrl;
            }
        } catch (error) {
            console.log(`Attempt ${i + 1}/${retries}: Waiting for Chrome to initialize...`);
            await sleep(delay);
        }
    }
    throw new Error('Failed to get WebSocket URL after multiple attempts');
}

async function main() {
    try {
        // Open Chrome in remote debugging mode
        openChrome(); // Removed await as requested
        console.log('Chrome opened with remote debugging mode enabled.');

        // Wait for Chrome to start and get the WebSocket URL
        console.log('Waiting for Chrome to initialize...');
        const webSocketUrl = await getChromeWebSocketUrl();
        console.log('WebSocket URL:', webSocketUrl);

        // Optional: Wait for a moment before closing Chrome
        await sleep(2000);

        // Close Chrome
        await closeChrome();
        
        return webSocketUrl;
    } catch (error) {
        console.error('Error:', error);
        await closeChrome(); // Try to close Chrome even if there was an error
        throw error;
    }
}

// Handle cleanup when the script is interrupted
process.on('SIGINT', async () => {
    console.log('\nClosing Chrome and exiting...');
    await closeChrome();
    process.exit(0);
});

main().catch(error => {
    console.error('Error in main function:', error);
});