const { app, BrowserWindow, ipcMain  } = require('electron');
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const pdfParse = require('pdf-parse');
const { main: linkedInFiller } = require('./example_usage');  
const { getUserInfoJson } = require("./gpt_handler"); 
const { sendToExcel } = require("./sendToForms"); 
const multer = require('multer');
const {decode} = require('./encrypt')
const logger = require('./logger');
const {countLinksByTimeframe} = require('./utils');

// Express app setup
const expressApp = express();
expressApp.use(cors());
expressApp.use(express.json());

// Global variables
let mainWindow;
let server;
let browser;

// Serve static files
expressApp.use(express.static(path.join(__dirname, '../website')));
expressApp.use('/server', express.static(path.join(__dirname, 'frontend')));

// Basic routes
// expressApp.get('/', (req, res) => {
//     res.redirect('https://harshkgpian.github.io/website/');
// });

// expressApp.get('/server', (req, res) => {
//     res.sendFile(path.join(__dirname, 'frontend/server.html'));
// });

expressApp.get('/api/ping', (req, res) => {
    res.json({ status: 'ok', message: 'Server is running' });

});

ipcMain.on('close-server', () => {
    // stopServer();
    app.quit();
});


function safeJSONParse(data) {
    try {
        return {
            success: true,
            data: JSON.parse(data)
        };
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

function safeJSONStringify(data, indent = 2) {
    try {
        return {
            success: true,
            data: JSON.stringify(data, null, indent)
        };
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

async function extractTextFromPDF(pdfPath) {
    try {
        if (!fs.existsSync(pdfPath)) {
            throw new Error('PDF file not found');
        }
        const pdfBuffer = fs.readFileSync(pdfPath);
        const pdfData = await pdfParse(pdfBuffer);
        return pdfData.text;
    } catch (error) {
        throw new Error(`Error extracting text from PDF: ${error.message}`);
    }
}



const getAppDataPath = () => {
    let basePath;
    switch (process.platform) {
        case 'win32':
            // Use Windows AppData/Local directory
            basePath = process.env.LOCALAPPDATA || path.join(process.env.USERPROFILE, 'AppData', 'Local');
            break;
        case 'darwin':
            // Use macOS Application Support directory
            basePath = path.join(process.env.HOME, 'Library', 'Application Support');
            break;
        case 'linux':
            // Use XDG_DATA_HOME specification for Linux
            basePath = process.env.XDG_DATA_HOME || path.join(process.env.HOME, '.local', 'share');
            break;
        default:
            // Fallback for other systems
            basePath = process.env.XDG_DATA_HOME || path.join(process.env.HOME, '.local', 'share');
    }
    
    const customDataFolder = path.join(basePath, 'LinkedInAutomation', 'Data');
    
    try {
        // Create directory with restricted permissions
        if (!fs.existsSync(customDataFolder)) {
            fs.mkdirSync(customDataFolder, { 
                recursive: true, 
                // 0700 means read/write/execute for owner only
                mode: 0o700
            });
        }
        
        // Ensure permissions are correct even if directory already existed
        fs.chmodSync(customDataFolder, 0o700);
        
        return customDataFolder;
    } catch (error) {
        console.error('Error creating/accessing app data directory:', error);
        throw error;
    }
};


const userDataPath = path.join(getAppDataPath(), 'userData.json');
console.log("User data path:", userDataPath);
const uploadFolder = path.join(getAppDataPath(), 'uploads');
if (!fs.existsSync(uploadFolder)) {
    fs.mkdirSync(uploadFolder); // Create the folder if it doesn't exist
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadFolder); // Save files in the "uploads" folder
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname); // Save with the original filename
    },
});

const upload = multer({ storage });
// API endpoint for PDF uploads

function saveUserData(data, filePath) {
    try {
        // Ensure the directory exists before saving the file
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true }); // Create directories if they don't exist
        }

        const jsonString = JSON.stringify(data, null, 2);

        // Write the JSON string to the file
        fs.writeFileSync(filePath, jsonString, 'utf8');
        console.log(`User data successfully saved to: ${filePath}`);
        return true;
    } catch (error) {
        console.error(`Error saving user data to ${filePath}:`, error);
        return false;
    }
}

function loadUserData(userDataPath) {
    try {
        if (!fs.existsSync(userDataPath)) {
            return null;
        }
        const fileContent = fs.readFileSync(userDataPath, 'utf8');
        return JSON.parse(fileContent);
    } catch (error) {
        console.error('Error loading user data:', error);
        return null;
    }
}

const displayErrorMessage = (window, message) => console.error(message);


expressApp.get('/api/load-saved-data', async (req, res) => {
    try {
        const userData = loadUserData(userDataPath);
        console.log("User data:", userData);
        if (userData) {
            return res.json({ success: true, data: userData });
        }
        return res.status(404).json({ success: false, message: 'No saved data found' });
    } catch (error) {
        displayErrorMessage(null, `Error loading saved data: ${error.message}`);
        return res.status(500).json({ success: false, message: `Error loading saved data: ${error.message}` });
    }
});

expressApp.post("/api/upload-pdf", upload.single("file"), (req, res) => {
    const uploadedFile = req.file;
    const uploadedFilePath = uploadedFile.path; // The temporary path where the file was uploaded

    // Define the final file path in the 'uploads' folder
    const finalFilePath = path.join(uploadFolder, uploadedFile.originalname);

    // Check if the file is already in the uploads folder
    if (!uploadedFilePath.includes(uploadFolder)) {
        // Move the file to the 'uploads' folder if it's not already there
        fs.renameSync(uploadedFilePath, finalFilePath);
    }

    res.json({ success: true, message: "PDF file uploaded successfully!" });
});







expressApp.post("/api/save-data", async (req, res) => {
    const { credentials, searchParams, key } = req.body;
    console.log("Request body:", credentials, searchParams, key);

    // Validate required fields
    if (!credentials || !credentials.path) {
        return res.status(400).json({ success: false, message: "All required fields must be filled." });
    }

    try {
        // First check user's premium status and available jobs
        const userJobInfoResponse = await fetch('https://www.jobassistant.in/get-user-job-info', {
            method: 'GET',
            headers: {
                'x-user-email': key.email,
            },
        });

        if (!userJobInfoResponse.ok) {
            throw new Error(`Failed to fetch user job info: ${userJobInfoResponse.statusText}`);
        }

        const userJobInfo = await userJobInfoResponse.json();
        if (!userJobInfo.success) {
            throw new Error(userJobInfo.error || 'Failed to fetch user job info');
        }

        const { isPremium, availableJobs } = userJobInfo;

        // Check existing applied jobs
        const jobsAppliedPath = path.join(getAppDataPath(), 'JobsApplied.js');
        const { links, last24Hours, lastMonth } = countLinksByTimeframe(jobsAppliedPath);
        const appliedJobsCount = links.length;

        // Check various limits
        if (last24Hours >= 40) {
            return res.status(403).json({
                success: false,
                message: "Daily application limit reached (40 applications per 24 hours)."
            });
        }

        if (lastMonth >= 1000) {
            return res.status(403).json({
                success: false,
                message: "Monthly application limit reached (1000 applications per month)."
            });
        }

        if (!isPremium && appliedJobsCount >= availableJobs) {
            return res.status(403).json({
                success: false,
                message: `You have reached your limit of ${availableJobs} job applications. Please upgrade to continue.`
            });
        }

        // Load existing user data
        const userDataPath = path.join(getAppDataPath(), 'userData.json');
        let existingData = loadUserData(userDataPath);

        // If no existing data is found, initialize it
        if (!existingData) {
            console.log('No existing data found. Creating new user data file.');
            existingData = {
                credentials: {},
                searchParams: {},
                key: {},
                userDataJSON: {}
            };
        }

        console.log('Existing data:', existingData);
        console.log('Incoming key:', key);

        // Decode validation code
        console.log("Decoding validation code...");
        const decodedData = decode(key.validationCode);
        console.log("Decoded data:", decodedData);

        if (!decodedData) {
            return res.status(400).json({ success: false, message: 'Invalid validation code.' });
        }

        const API_KEY = decodedData.key.Api;
        console.log("API key:", API_KEY);

        // Resolve PDF file path
        let pdfFilePath = credentials.path;
        if (!path.isAbsolute(pdfFilePath)) {
            pdfFilePath = path.join(uploadFolder, pdfFilePath);
        }

        // Validate PDF file existence
        if (!fs.existsSync(pdfFilePath)) {
            return res.status(400).json({ success: false, message: `PDF file not found.`});
        }

        credentials.path = pdfFilePath;

        // Check if PDF path has changed
        const isPdfPathChanged = !existingData.credentials || existingData.credentials.path !== pdfFilePath;

        let processedUserData;
        if (isPdfPathChanged) {
            logger.log('Processing resume...');
            let extractedText = await extractTextFromPDF(pdfFilePath);
            const ctcInfo = `
                Notice Period: ${credentials.noticePeriod}
                Current CTC: ${credentials.curCTC}
                Expected CTC: ${credentials.expCTC}
            `;
            extractedText = extractedText + '\n' + ctcInfo;

            processedUserData = await getUserInfoJson(extractedText, API_KEY, existingData.key.email);

            if (processedUserData.error === "Request processing failed") {
                return res.status(500).json({ success: false, message: 'Failed to process resume data. Please try again.' });
            }
        } else {
            processedUserData = existingData.userDataJSON;
        }

        // Prepare final data
        const userData = {
            credentials: credentials,
            searchParams: searchParams,
            key: key,
            userDataJSON: processedUserData
        };

        // Save data
        if (!saveUserData(userData, userDataPath)) {
            throw new Error('Failed to save user data.');
        }

        // Start LinkedIn automation
        try {
            logger.log('Starting LinkedIn automation...');
            const progressCallback = (status) => {
                console.log(`Automation progress: ${status}`);
            };

            await linkedInFiller(
                userData.credentials,
                userData.searchParams,
                userData.userDataJSON,
                key,
                API_KEY,
                getAppDataPath(),
                progressCallback
            );

            logger.log('LinkedIn automation completed successfully!');

            res.json({
                success: true,
                message: 'Data saved and LinkedIn automation started successfully!',
                jobsRemaining: isPremium ? 'unlimited' : (availableJobs - appliedJobsCount)
            });
        } catch (automationError) {
            console.error(`Automation error: ${automationError.message}`);
            return res.status(500).json({ success: false, message: `Automation error: ${automationError.message}` });
        }
    } catch (error) {
        console.error(`Error: ${error.message}`);
        res.status(500).json({ success: false, message: `Error: ${error.message}` });
    }
});


expressApp.get('/api/logs', (req, res) => {
    res.json({ success: true, logs: logger.getLogs() });
});


// Example usage
logger.log("Server started successfully");
// terminalLog("New job statistics fetched");


// Window management
function createWindow() {
    mainWindow = new BrowserWindow({
        width: 400,
        height: 1200,
        frame: false,
        resizable: false,
        transparent: true,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        }
    });

    // Load the server frontend
    mainWindow.loadFile(path.join(__dirname, 'frontend/server.html'));

    // Start Express server
    const port = 3110;
    server = expressApp.listen(port, 'localhost', () => {
        console.log(`Server running on http://localhost:${port}`);
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.error('Port 3000 is already in use. Please close other applications using this port.');
        } else {
            console.error('Server error:', err);
        }
    });

    // Debug: Open DevTools
    // mainWindow.webContents.openDevTools();
}

// Cleanup function
async function cleanup() {
    try {
        if (browser) {
            await browser.close();
        }
        if (server) {
            server.close(() => {
                console.log('Server closed');
                app.quit();
            });
        } else {
            app.quit();
        }
    } catch (error) {
        console.error('Cleanup error:', error);
        app.quit();
    }
}



// Electron app lifecycle
app.whenReady().then(createWindow);
app.on('window-all-closed', cleanup);
app.on('before-quit', cleanup);
app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

// Error handling
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled Rejection:', error);
});