const fs = require('fs');  
const { encode,decode } = require('./encrypt');

// To add the user in the database 

// Example usage:
// const jsonObject = {  
//     key: {  
//         email: "ravikesh@gmail.com",  
//         password: "ravikesh",  
//         Api: "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"  
//     }  
//   };
//   const filePath = 'encrypted1.key';
  
// //   // Encode data
// //   encode(JSON.stringify(jsonObject), filePath);
  
//   // Decode data from file
//   const decodedData = decode(filePath);
//   const key = JSON.parse(decodedData).key
//   console.log("Decoded Data:", JSON.parse(decodedData).key);



// function sendTerminalMessage(message) {    
//     if (mainWindow && !mainWindow.isDestroyed()) {    
//         try {  
//             mainWindow.webContents.send('terminal-output', {   
//                 message: message,  
//                 timestamp: new Date().toISOString()  
//             });    
//         } catch (error) {  
//             console.error('Error sending message to renderer:', error);  
//         }  
//     }    
// } 
  
function ensureFile(filePath) {  
        if (!fs.existsSync(filePath)) {  
            console.log(`Creating ${filePath}...`);  
            const initialContent = `module.exports = [];\n`;  
            fs.writeFileSync(filePath, initialContent, 'utf8');  
            console.log(`${filePath} created successfully.`);  
        }  
    }  


function appendLinks(filePath, links) {  
    try {  
        // Ensure the file exists  
        ensureFile(filePath);  

        // Load existing links  
        let existingLinks = [];  
        try {  
            existingLinks = require(filePath); // Load existing data  
        } catch (error) {  
            console.error(`Error loading existing links from ${filePath}: ${error.message}`);  
        }  

        // Append new links and remove duplicates  
        const updatedLinks = [...existingLinks, ...links];  
        const uniqueLinks = Array.from(new Set(updatedLinks));  

        // Save back to the file  
        const fileContent = `module.exports = ${JSON.stringify(uniqueLinks, null, 2)};\n`;  
        fs.writeFileSync(filePath, fileContent, 'utf8');  
        console.log(`Appended ${links.length} links to ${filePath}.`);  
    } catch (error) {  
        console.error(`Error appending links to ${filePath}: ${error.message}`);  
    }  
}  
 

// Append a single link to the file  
// const fs = require('fs');

async function appendLink(filePath, link, email) {
    const adminKey = "b7e5f8c9-3d4a-4e2b-8f6a-9c1d2e3f4b5a"  
    try {  
        // Local file operations for links
        ensureFile(filePath);  
        
        let existingLinks = [];  
        try {  
            const fileContent = fs.readFileSync(filePath, 'utf8');  
            existingLinks = eval(fileContent.replace('module.exports =', '').trim());
        } catch (error) {  
            console.error(`Error loading existing links from ${filePath}: ${error.message}`);  
        }  

        // Create a new link object with timestamp
        const timestampedLink = {
            link: link,
            timestamp: new Date().toISOString()
        };

        // Update local file
        const updatedLinks = [...existingLinks, timestampedLink];  
        const uniqueLinks = Array.from(new Set(updatedLinks.map(a => a.link)))  
                                  .map(link => updatedLinks.find(a => a.link === link));

        const fileContent = `module.exports = ${JSON.stringify(uniqueLinks, null, 2)};\n`;  
        fs.writeFileSync(filePath, fileContent, 'utf8');  
        console.log(`Appended link to local file ${filePath}: ${link}`);

        // Update jobsApplied count in database
        console.log('Updating jobs applied count in database...', email);
        console.log('Request body:', JSON.stringify({ userEmail: email }));

        try {
            const response = await fetch('http://jobassistant.in/append-jobs-applied', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-admin-key': adminKey
                },
                body: JSON.stringify({
                    userEmail: email
                })
            });

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.message || 'Failed to update jobs applied count');
            }

            console.log('Successfully updated jobs applied count in database');
            return { success: true, local: true, database: true };

        } catch (dbError) {
            console.error('Database update failed:', dbError);
            return { success: true, local: true, database: false, error: dbError.message };
        }

    } catch (error) {  
        console.error(`Error in appendLink: ${error.message}`);
        return { success: false, local: false, database: false, error: error.message };
    }  
}
        
async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// const fs = require('fs');

// function readLinks(filePath) {
//     try {
//         // Load existing links from the file
//         const fileContent = fs.readFileSync(filePath, 'utf8');
//         const existingLinks = eval(fileContent.replace('module.exports =', '').trim()); // Safely parse the array
//         return existingLinks;
//     } catch (error) {
//         console.error(`Error loading existing links from ${filePath}: ${error.message}`);
//         return [];
//     }
// }
// const fs = require('fs');

function countLinksByTimeframe(filePath) {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf8');
        const links = eval(fileContent.replace('module.exports =', '').trim()); // Safely parse the array

        const now = new Date();
        const twentyFourHoursAgo = new Date(now - 24 * 60 * 60 * 1000); // 24 hours ago
        const oneMonthAgo = new Date(now.setMonth(now.getMonth() - 1)); // 1 month ago

        // Filter links added in the last 24 hours
        const linksLast24Hours = links.filter(link => new Date(link.timestamp) > twentyFourHoursAgo);
        // Filter links added in the last month
        const linksLastMonth = links.filter(link => new Date(link.timestamp) > oneMonthAgo);

        return {
            links, // Include the original links array in the output
            last24Hours: linksLast24Hours.length,
            lastMonth: linksLastMonth.length
        };
    } catch (error) {
        console.error(`Error counting links by timeframe: ${error.message}`);
        return { links: [], last24Hours: 0, lastMonth: 0 };
    }
}




module.exports = {
    delay,
    appendLinks,
    appendLink,
    countLinksByTimeframe
}