// logger.js
let logMessages = [];

class Logger {
    constructor(maxLogs = 100) {
        this.maxLogs = maxLogs;
    }

    log(message) {
        const logEntry = " - " + message;
        
        // Log to the server console
        console.log(logEntry);

        // Save log to memory
        logMessages.push(logEntry);

        // Limit log history
        if (logMessages.length > this.maxLogs) {
            logMessages.shift();
        }
    }

    getLogs() {
        return logMessages;
    }

    clearLogs() {
        logMessages = [];
    }
}

// Create and export a singleton instance
const logger = new Logger();

module.exports = logger;

// If you're using ES modules, use this instead:
// export default logger;