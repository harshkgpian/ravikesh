const puppeteer = require('puppeteer');

async function scrapeLinkedInJobs(jobTitle = 'Data Science', location = 'United States') {
    try {
        const browser = await puppeteer.launch({
            headless: false, // Set to true for production
            defaultViewport: null
        });

        const page = await browser.newPage();

        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');

        const searchUrl = constructJobSearchUrl(jobTitle, location, {
            experienceLevel: "Entry level",
            workType: "Remote",
            datePosted: "Past Week",
            easyApply: true
        });

        console.log('Navigating to:', searchUrl);
        await page.goto(searchUrl, { waitUntil: 'networkidle2' });

        // Attempt to close the Sign-In modal if it appears
        await closeSignInModal(page);

        console.log('Loading more jobs...');
        await autoScroll(page);

        console.log('Extracting job links...');
        const jobLinks = await getJobLinks(page);

        console.log('\nFound Jobs:');
        jobLinks.forEach((link, index) => {
            console.log(`${index + 1}. ${link}`);
        });

        await browser.close();
        return jobLinks;
        
    } catch (error) {
        console.error('Error during scraping:', error);
        return [];
    }
}

// Function to close the sign-in modal
async function closeSignInModal(page) {
    try {
        const modalDismissSelector = 'button.modal__dismiss';
        await page.waitForSelector(modalDismissSelector, { timeout: 3000 });
        await page.click(modalDismissSelector);
        console.log('Sign-in modal dismissed.');
    } catch (error) {
        console.log('No sign-in modal detected.');
    }
}

// Auto-scroll function with delay
async function autoScroll(page) {
    await page.evaluate(async () => {
        await new Promise((resolve) => {
            let totalHeight = 0;
            const distance = 200;
            const delay = 300;
            const timer = setInterval(() => {
                const scrollHeight = document.body.scrollHeight;
                window.scrollBy(0, distance);
                totalHeight += distance;

                if (totalHeight >= scrollHeight || totalHeight > 10000) {
                    clearInterval(timer);
                    resolve();
                }
            }, delay);
        });
    });
}

// Function to construct LinkedIn job search URL
function constructJobSearchUrl(jobTitle, location, filters = {}) {
    const baseUrl = "https://www.linkedin.com/jobs/search/?";
    const params = new URLSearchParams({
        keywords: jobTitle,
        location: location,
        distance: "25",
        f_AL: filters.easyApply ? "true" : "false",
    });

    const experienceLevels = { "Internship": "1", "Entry level": "2", "Associate": "3", "Mid-Senior level": "4", "Director": "5", "Executive": "6" };
    if (filters.experienceLevel) params.append("f_E", experienceLevels[filters.experienceLevel]);

    const workTypes = { "Remote": "2", "On-site": "1", "Hybrid": "3" };
    if (filters.workType) params.append("f_WT", workTypes[filters.workType]);

    const datePostedOptions = { "Past 24 hours": "r86400", "Past Week": "r604800", "Past Month": "r2592000" };
    if (filters.datePosted) params.append("f_TPR", datePostedOptions[filters.datePosted]);

    return baseUrl + params.toString();
}

// Function to extract job links
async function getJobLinks(page) {
    try {
        await page.waitForSelector('li[data-occludable-job-id]', { timeout: 10000 });

        const jobIds = await page.evaluate(() => {
            return [...document.querySelectorAll('li[data-occludable-job-id]')]
                .map(job => job.getAttribute('data-occludable-job-id'))
                .filter(id => id);
        });

        console.log(`Extracted ${jobIds.length} job IDs`);

        return jobIds.map(id => `https://www.linkedin.com/jobs/view/${id}`);
    } catch (error) {
        console.error("Error extracting job links:", error);
        return [];
    }
}

// Run script
(async () => {
    console.log('Starting LinkedIn job search...');
    const jobs = await scrapeLinkedInJobs('Data Science', 'United States');
    console.log(`\nTotal jobs found: ${jobs.length}`);
})();
